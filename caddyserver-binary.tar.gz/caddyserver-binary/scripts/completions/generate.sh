#!/usr/bin/env bash

completely --shell zsh caddy.json > _caddy
completely --shell bash caddy.json > bash-completion
