#!/bin/bash

rm /var/log/*.log
rm -rf /var/log/unattended-upgrades
rm -rf /root/.ansible
